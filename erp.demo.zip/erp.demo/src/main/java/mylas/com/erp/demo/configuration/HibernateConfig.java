package mylas.com.erp.demo.configuration;

public class HibernateConfig {

}
