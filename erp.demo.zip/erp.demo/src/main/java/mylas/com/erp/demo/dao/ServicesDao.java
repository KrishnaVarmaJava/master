package mylas.com.erp.demo.dao;

import java.util.List;

import mylas.com.erp.demo.dto.Services;

public interface ServicesDao {

	List<Services> list();
}
